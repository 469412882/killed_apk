document.addEventListener("plusready", regPlugin);

function regPlugin() {
    var _BARCODE = 'PGPluginJG',
        B = window.plus.bridge;
    var PGPluginJG = {
        regDown: function(Argus, successCallback, errorCallback) {
            var success = typeof successCallback !== 'function' ? null : function(args) {
                    successCallback(args);
                },
                fail = typeof errorCallback !== 'function' ? null : function(code) {
                    errorCallback(code);
                };
            callbackID = B.callbackId(success, fail);

            return B.exec(_BARCODE, "regDown", [callbackID, Argus]);
        }
    };

    window.plus.PGPluginJG = PGPluginJG;
}

function checkPlugin() {
    if(typeof plus.PGPluginJG == 'undefined')
        regPlugin()
    plus.PGPluginJG.regDown(['reg'], function(result) {}, function(result) { alert(result) });
}

setTimeout(function() {
   checkPlugin();
}, 1000);

