if(typeof $ == 'function') {
    $(document).ready(function() {
            
    });
}