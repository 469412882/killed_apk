if(typeof mui == 'undefined') alert('not found mui');
var appname = '彩票走势图';
var zlapp = (function($) {
    var com = {};
    var webViewStyles = {
            //自定义部分
            isWaiting: false,
        },
        webViewOptions = {
            //          acceleration:'capture'
        };

    //创建新页面
    var _createPage = function(url, pstyles, pconfig) {
        if(!url) {
            console.log('url不能为空');
            return null;
        }
        pconfig || (pconfig = {});
        pconfig = $.extend(false, webViewOptions, pconfig);

        pstyles || (pstyles = {});
        pstyles = $.extend(false, webViewStyles, pstyles);
        var pid = pstyles.pid || url;

        var _p = mui.openWindow({
            url: url,
            id: pid,
            styles: pstyles,
            extras: pconfig
        });

        return _p;
    };

    //退出app
    var _quitFirst = null
    var _quitApp = function() { //注册android连续两次退出
        var self = this;
        $.back = function() {
            //判断菜单是否显示部分
            if(typeof index_slidemenu === "object" && !index_slidemenu.back()) return false;

            //首次按键，提示‘再按一次退出应用’
            if(!_quitFirst) {
                _quitFirst = new Date()
                    .getTime();
                _showToast('再按一次退出应用');
                setTimeout(function() {
                    _quitFirst = null;
                }, 1000);
            } else {
                if(new Date()
                    .getTime() - _quitFirst < 1000) {
                    plus.runtime.quit();
                }
            }
        };
    };

    //创建新的webView
    com.createPage = _createPage;

    //封装androin连续两次返回退出app
    com.quitApp = _quitApp;

    return com;
})(mui);

//页面自适应
(function(doc, win) {
    doc.documentElement.style.fontSize = '10px';
})(document, window);